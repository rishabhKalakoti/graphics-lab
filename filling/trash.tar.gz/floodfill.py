from graphics import *
from drawLine import *
import viewport
from viewport import screenArr as screenArr

def floodFill(x,y):
	global screenArr
	vp = viewport.vp
	stack = list()
	stack.append(Point(x,y))
	while len(stack)>0:
		pt = stack.pop(0)
		if not(screenArr[pt.y][pt.x]==2 or screenArr[pt.y][pt.x]==1):
			# colour
			viewport.putFill(pt)
			# push neighbours
			if not(screenArr[pt.y+1][pt.x]==2 or screenArr[pt.y+1][pt.x]==1):
				stack.append(Point(pt.x,pt.y+1))
			if not(screenArr[pt.y][pt.x+1]==2 or screenArr[pt.y][pt.x+1]==1):
				stack.append(Point(pt.x+1,pt.y))
			if not(screenArr[pt.y-1][pt.x]==2 or screenArr[pt.y-1][pt.x]==1):
				stack.append(Point(pt.x,pt.y-1))
			if not(screenArr[pt.y][pt.x-1]==2 or screenArr[pt.y][pt.x-1]==1):
				stack.append(Point(pt.x-1,pt.y))
			

def floodfillInterface():
	print("Enter the number of points in the polygon.")
	n = int(input())
	l=list()
	print("Enter the coords of points one by one.")
	while n>0:
		x,y = input().split()
		l.append([int(x),int(y)])
		n-=1
	print("Give the coords of the seed")
	x,y = input().split()
	x=int(x)
	y=int(y)
	viewport.initWindow()
	# print(l)
	n = len(l)
	for i in range(n):
		drawLine(l[i%n][0],l[i%n][1],l[(i+1)%n][0],l[(i+1)%n][1])
	floodFill(x,y)
	viewport.closeWin()
